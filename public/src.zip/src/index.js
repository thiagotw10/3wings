import { grafico, qualidadeEntrega, qualidadeServicos, entregaRodovia, entregaOrigem, porOrigem, porStatus, porPrograma, porProgramaStatus, porRodoviaStatus, porRodoviaRisco } from './assets/js/modelos-graficos/graficos.js'

const urlParams = new URLSearchParams(window.location.search);
const token = urlParams.get('token');
const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
const urlFiltro = 'https://homolog.crb.audax.mobi/homolog/rest/conserva/getFiltros'
const urlDash = 'https://homolog.crb.audax.mobi/homolog/rest/conserva/getDashboard'

window.onload = ()=>{
    $('#checkboxUm').each(function(){ this.checked = true; });

    var calendars = bulmaCalendar.attach('[type="date"]', {
      startDate: dataIntervalo().inicioAnterior,
      endDate: dataIntervalo().inicio,
      cancelLabel: 'Cancelar',
      clearLabel: 'Apagar',
      todayLabel: 'Hoje',
    });
   
    axios.get(urlFiltro, config)
    .then(function (response) {
     
     for (const [key, value] of Object.entries(response.data.filtroOrigem)) {
        addOptionFiltroOrigem(key, value)
      }
  
      function addOptionFiltroOrigem(chave,valor) {
        let option = new Option(valor, chave);
        let select = document.getElementById("filtroOrigem");
        select.add(option);
      }

      for (const [key, value] of Object.entries(response.data.filtroPrograma)) {
        addOptionFiltroPrograma(key, value)
      }
  
      function addOptionFiltroPrograma(chave,valor) {
        let option = new Option(valor, chave);
        let select = document.getElementById("filtroPrograma");
        select.add(option);
      }

      for (const [key, value] of Object.entries(response.data.filtroRodovia)) {
        addOptionFiltroRodovia(key, value)
      }
  
      function addOptionFiltroRodovia(chave,valor) {
        let option = new Option(valor, chave);
        let select = document.getElementById("filtroRodovia");
        select.add(option);
      }

      for (const [key, value] of Object.entries(response.data.responsaveis)) {
        addOptionFiltroResponsaveis(key, value)
      }
  
      function addOptionFiltroResponsaveis(chave,valor) {
        let option = new Option(valor, chave);
        let select = document.getElementById("filtroResponsavel");
        select.add(option);
      }

    })
    .catch(function (error) {
      // manipula erros da requisição
      console.error(error);
    })
    .then(function () {
      // sempre será executado
    });

    carregar(0)
}

document.getElementById('filtrar').addEventListener('click', (e)=>{
    e.preventDefault()

    function toJSONLocal(date) {
        var local = new Date(date);
        return local.toJSON().slice(0, 10);
      }

      if(!$("#intervalo").val()){
        return alert('Intervalo de data sem data')
      }
      

    let programa = $("#filtroPrograma").val()
    let origem = $("#filtroOrigem").val()
    let rodovia = $("#filtroRodovia").val()
    let intervalo = $("#intervalo").val()
    let responsaveis = $("#filtroResponsavel").val()
    let inicio = intervalo.split('-')[0]
    let fim = intervalo.split('-')[1]

    var filtro = []
    filtro.push({
        inicio: toJSONLocal(inicio),
        fim: toJSONLocal(fim),
       ...(programa == "" ? null : {programaId: programa}),
       ...(rodovia == "" ? null : {rodoviaId: rodovia}),
       ...(origem == "" ? null : {origemOrdinal: origem}),
       ...(responsaveis == "" ? null : {responsavel: responsaveis})  
    })
         
    carregar(filtro[0])
})

var dataIntervalo = ()=>{
    let inicio = new Date()
    let dia = inicio.getDate()
    let mes = (inicio.getMonth() + 1) - 2
    let ano = inicio.getFullYear()
    var inicioAnterior = new Date(ano, mes, dia)
    inicioAnterior = inicioAnterior.toISOString().slice(0, 10)
    inicio = inicio.toISOString().slice(0, 10)
    return {inicioAnterior, inicio}
}

function carregar(data){

    let dataOnload = [{
        "inicio": dataIntervalo().inicioAnterior,
        "fim": dataIntervalo().inicio,
    }]

    $("#filtrar").addClass("is-loading");
    let filtro = data == 0 ? dataOnload[0] : data

    axios.post(urlDash, filtro, config)
    .then(function (response) {
        $("#filtrar").removeClass("is-loading");
        $("#filtroModal").addClass("is-hidden");
        let cardAberto = response.data.cards.pendente || 0
        let cardAndamento = response.data.cards.andamento || 0
        let cardAtraso = response.data.cards.atraso || 0
        let cardExecutada = response.data.cards.executada || 0
        let cardFora = response.data.cards.executadaForaPrazo || 0
        $("#aberto").html(`<b>${cardAberto}</b> em aberto`)
        $("#andamento").html(`<b>${cardAndamento}</b> em andamento`)
        $("#atrasado").html(`<b>${cardAtraso}</b> em atrasos`)
        $("#prazo").html(`<b>${cardExecutada}</b> superadas no prazo`)
        $("#foraPrazo").html(`<b>${cardFora}</b> superadas fora do prazo`)
     
        grafico(response.data.grafico.aberto, response.data.grafico.superado)
        qualidadeEntrega(response.data.qualidades.prazo, response.data.qualidades.atrasada)
        let arrayQualidade = []
        response.data.qualidadeServicos.forEach(val => {
            arrayQualidade.push({
                year: val.atividade,
                aberto: val.pendente || 10,
                andamento: val.andamento || 2,
                prazo: val.executada || 4,
                fora: val.executadaForaPrazo || 5
            })
        });
        qualidadeServicos(arrayQualidade)
        let arrayRodovia = []
        response.data.rodoviasOperacional.forEach(val =>{
            arrayRodovia.push({
                "year": val.rodovia,
                "aberto": val.pendente,
                "andamento": val.andamento,
                "prazo": val.executada,
                "fora": val.executadaForaPrazo,
            })
        })
        entregaRodovia(arrayRodovia)
        let arrayOrigem = []
        response.data.origemOperacional.forEach(val =>{
            arrayOrigem.push({
                "year": val.origem,
                "aberto": val.pendente,
                "andamento": val.andamento,
                "prazo": val.executada,
                "fora": val.executadaForaPrazo,
            })
        })
        entregaOrigem(arrayOrigem)
        porOrigem(response.data.origem.din, response.data.origem.dop, response.data.origem.ma, response.data.origem.kria, response.data.origem.i, response.data.origem.ouvidoria)
        porStatus(response.data.status.pendente, response.data.status.andamento, response.data.status.atraso, response.data.status.executada, response.data.status.executadaForaPrazo)
        let porProgramas = []
        response.data.programas.forEach(val =>{
            porProgramas.push({
                year: val.nome,
                aberto: val.valor,
            })
        })
        porPrograma(porProgramas)
        let porProgramasStatus = []
        response.data.programasStatus.forEach(val =>{
            porProgramasStatus.push({
                "year": val.programa,
                "pendente": val.pendente,
                "andamento": val.andamento,
                "atraso": val.atraso,
                "executada": val.executada,
                "executadaForaPrazo": val.executadaForaPrazo,
            })
        })
        porProgramaStatus(porProgramasStatus)
        let porRodoviasStatus = []
        response.data.rodoviasStatus.forEach(val =>{
            porRodoviasStatus.push({
                "year": val.rodovia,
                "aberto": val.pendente,
                "andamento": val.andamento,
                "atraso": val.atraso,
                "prazo": val.executada,
                "fora": val.executadaForaPrazo,
            })
        })
        porRodoviaStatus(porRodoviasStatus)
        let rodoviaRisco = []
        response.data.rodovias.forEach(val =>{
            rodoviaRisco.push({
                year: val.nome.slice(0, 6),
                aberto: val.valor,
            })
        })
        porRodoviaRisco(rodoviaRisco)

    })
    .catch(function (error) {
      // manipula erros da requisição
      console.error(error);
    })
    .then(function () {
      // sempre será executado
    });
}