function filtro(){
    $("#filtro").toggle();
    $("#filtroModal").removeClass("is-hidden");
    $("#filtroModal").addClass("is-active");
}

function trocarTela(){
    $("#telaUm").removeClass("is-hidden");
    $("#telaUm").addClass("is-active");
    $("#telaDois").removeClass("is-hidden");
    $("#telaDois").addClass("is-hidden");
    $("#modalCard").removeClass("is-hidden");
    $("#modalCard").addClass("is-active");
    $('#checkboxUm').each(function(){ this.checked = true; });
    $('#checkboxDois').each(function(){ this.checked = false; });
}

function trocarTelaDois(){
    $("#telaUm").removeClass("is-active");
    $("#telaUm").addClass("is-hidden");
    $("#telaDois").removeClass("is-hidden");
    $("#telaDois").addClass("is-active");
    $("#modalCard").removeClass("is-active");
    $("#modalCard").addClass("is-hidden");
    $('#checkboxUm').each(function(){ this.checked = false; });
    $('#checkboxDois').each(function(){ this.checked = true; }); 
}


