document.write(`
            <div class="graficos-modais">
                <span class="has-text-weight-bold">Por origem</span>
                <div class="grafico-dash">
                    <div id="porOrigem" style="width: 100%; min-height: 350px;">

                    </div>
                </div>
            </div>
            <div class="graficos-modais">
                <span class="has-text-weight-bold">Por status</span>
                <div class="grafico-dash">
                    <div id="porStatus" style="width: 100%; min-height: 350px;">

                    </div>
                </div>
            </div>
            <div class="graficos-modais x">
                <span class="has-text-weight-bold">Por programa</span>
                <div class="grafico-dash">
                    <div id="porPrograma" style="width: 100%; min-height: 750px;">

                    </div>
                </div>
            </div>
            <div class="graficos-modais x">
                <span class="has-text-weight-bold">Por programa e status</span>
                <div class="grafico-dash">
                    <div id="porProgramaStatus" style="width: 100%; min-height: 750px;">

                    </div>
                </div>
            </div>

            <div class="graficos-modais x">
                <span class="has-text-weight-bold">Por rodovia e estágio</span>
                <div class="grafico-dash">
                    <div id="entregaRodoviaStatus" style="width: 100%; min-height: 750px;">

                    </div>
                </div>
            </div>
            
            <div class="graficos-modais x">
                <span class="has-text-weight-bold">Por rodovia</span>
                <div class="grafico-dash">
                    <div id="porRodoviaRisco" style="width: 100%; min-height: 750px;">

                    </div>
                </div>
            </div>

`)