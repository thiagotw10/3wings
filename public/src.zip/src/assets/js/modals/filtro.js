document.write(`

<div id="filtroModal" style="display: flex; justify-content: center; align-items: flex-start; background-color: #00000078; position: fixed; width: 100%; height: 100vh; left: 0; top: 0;">

    <div style="width: 40%; height: max-content; background-color: white; border-radius: 5px; display: flex; align-items: center; flex-direction: column; position: relative; margin: 30px 0">
        
        <div style="width: 85%; display: flex;justify-content: space-between; height: 70px; align-items: center;">
           <h1 style="font-size: 20px"><b>FILTRO DE PESQUISA</b></h1>
           <img onclick="filtro()" src="./assets/img/icone-fechar.svg" width="10"  alt="">  
        </div>

        <div style="width: 85%; display: flex; justify-content: space-between; flex-wrap: wrap;">
                <div style="display: flex; flex-direction: column; width: 45%; height: 100px" >
                <span style="margin-bottom: 10px">
                    Intervalo de data:
                </span>
                <input class="input is" type="date" id="intervalo"  data-is-range="false" data-close-on-select="true">
                </div>

                <div style="display: flex; flex-direction: column; width: 45%; height: 100px" >
                <span style="margin-bottom: 10px">
                    Por origem:
                </span>
                <div class="select">
                    <select style="width: 100%;" name="" id="filtroOrigem">
                    <option value="">Selecione uma origem</option>
                    </select> 
                </div>
                </div>


                <div style="display: flex; flex-direction: column; width: 45%; height: 100px" >
                <span style="margin-bottom: 10px">
                    Por programa:
                </span>
                <div class="select">
                    <select style="width: 100%;" name="" id="filtroPrograma">
                    <option value="">Selecione um programa</option>
                    </select> 
                </div>
                </div>
        
                <div style="display: flex; flex-direction: column; width: 45%; height: 100px" >
                <span style="margin-bottom: 10px">
                Por rodovia:
                </span>
                <div class="select">
                    <select style="width: 100%;" name="" id="filtroRodovia">
                    <option value="">Selecione uma rodovia</option>
                    </select> 
                </div>
                </div>

                <div style="display: flex; flex-direction: column; width: 45%; height: 100px" >
                <span style="margin-bottom: 10px">
                Por responsaveis:
                </span>
                <div class="select">
                    <select style="width: 100%;" name="" id="filtroResponsavel">
                    <option value="">Selecione um responsavel</option>
                    </select> 
                </div>
                </div>

      
        </div>


        <div style="width: 86%; display: flex; justify-content: end; right: 40px; bottom: 30px; height: 60px">
            <div style="width: 80%; height: 40px; display: flex; justify-content: right;">
                <button class="button" onclick="filtro()">Cancelar</button>
                <button class="button" id="filtrar" style="background-color: #079C4B; color: white; padding: 0 60px; margin-left: 10px;"> <img src="./assets/img/icone-filtrar-branco.svg" alt="" style="margin-right: 10px;"> Filtrar</button>
            </div>
        </div>

    </div>

</div>


`);
