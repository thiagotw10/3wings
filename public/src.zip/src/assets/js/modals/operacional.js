document.write(`
    <div class="graficos-modais">
    <span class="has-text-weight-bold">Gráficos</span>
    <div class="grafico-dash">
        <div id="grafico" style="width: 100%; height: 350px;">

        </div>
    </div>
    </div>
    <div class="graficos-modais">
    <span class="has-text-weight-bold">Qualidade da entrega de serviço</span>
    <div class="grafico-dash">
        <div id="qualidadeEntrega" style="width: 100%; min-height: 350px;">

        </div>
    </div>
    </div>
    <div class="graficos-modais x">
    <span class="has-text-weight-bold">Qualidade de Serviço</span>
    <div class="grafico-dash">
        <div id="qualidadeServico" style="width: 100%; min-height: 750px;">

        </div>
    </div>
    </div>
    <div class="graficos-modais x">
    <span class="has-text-weight-bold">Entrega por rodovia</span>
    <div class="grafico-dash">
        <div id="entregaRodovia" style="width: 100%; min-height: 750px;">

        </div>
    </div>
    </div>



        <div class="modal-entrega-origin">
        <span class="has-text-weight-bold">Entrega por origem</span>
        <div class="grafico-dash-origin">
            <div id="entregaOrigem" style="width: 100%; min-height: 750px;">

            </div>
        </div>
    
</div>

`)